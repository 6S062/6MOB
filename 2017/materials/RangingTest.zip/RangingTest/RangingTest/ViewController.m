//
//  ViewController.m
//  RangingTest
//
//  Created by Sam Madden on 2/15/17.
//  Copyright © 2017 Sam Madden. All rights reserved.
//

#import "ViewController.h"

#import <CoreLocation/CoreLocation.h>

@interface ViewController () <CLLocationManagerDelegate> {
    CLBeaconRegion *_defaultRegion;
    CLLocationManager *_locMgr;

}
@end

static NSString * const kBTLERegionIdentifierDefaultUUID = @"B8FED863-9F1C-447C-8F82-DF0C2E067DEA";
static NSString * const kBTLEDefaultRegionName = @"Region";


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSString *activeUUID = kBTLERegionIdentifierDefaultUUID;

    _defaultRegion = [[CLBeaconRegion alloc] initWithProximityUUID:[[NSUUID alloc] initWithUUIDString:activeUUID] identifier:kBTLEDefaultRegionName];
    _locMgr = [[CLLocationManager alloc] init];
    [_locMgr requestAlwaysAuthorization];
    _locMgr.delegate = self;

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    
    if (status == kCLAuthorizationStatusAuthorizedAlways) {
        NSLog(@"Location active");
        [_locMgr startRangingBeaconsInRegion:_defaultRegion];
    }
}


-(void)locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region {
}

-(void)locationManager:(CLLocationManager *)manager didEnterRegion:(nonnull CLRegion *)region {
}

-(void)locationManager:(CLLocationManager *)manager didDetermineState:(CLRegionState)state forRegion:(nonnull CLRegion *)region
{
    NSLog(@"Updated region: %@ to state %ld", region, state);
}

-(void)locationManager:(CLLocationManager *)manager didRangeBeacons:(nonnull NSArray<CLBeacon *> *)beacons inRegion:(nonnull CLBeaconRegion *)region
{
    for (CLBeacon *beacon in beacons) {
        NSLog(@"Ranged beacon %@", beacon);
        uint64_t tagMac = 0;
        tagMac |= ([[beacon minor] unsignedIntValue] & 0x0000FFFF)<< 16;
        tagMac |= [[beacon major] unsignedIntValue] & 0x0000FFFF;
        NSMutableString *hex = [NSMutableString stringWithCapacity:16];
        for (int i=0; i < 8; i++) {
            [hex appendFormat:@"%02x", ((uint8_t *)&tagMac)[i]];
        }

        NSString *prox;
        [self.idLabel setText:hex];
        switch(beacon.proximity) {
            case CLProximityFar:
                prox = @"Far";
                break;
            case CLProximityNear:
                prox = @"Near";
                break;
            case CLProximityUnknown:
                prox = @"Unknown";
                break;
            case CLProximityImmediate:
                prox = @"Immediate";
        }
        [self.rangeLabel setText:[NSString stringWithFormat:@"±%.2fm ('%@')", beacon.accuracy, prox]];
        [self.rssiLabel setText:[NSString stringWithFormat:@"%lddB",beacon.rssi]];
    }
}


@end
