//
//  main.m
//  RangingTest
//
//  Created by Sam Madden on 2/15/17.
//  Copyright © 2017 Sam Madden. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
