//
//  AppDelegate.h
//  RangingTest
//
//  Created by Sam Madden on 2/15/17.
//  Copyright © 2017 Sam Madden. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

