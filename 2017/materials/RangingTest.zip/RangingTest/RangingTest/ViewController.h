//
//  ViewController.h
//  RangingTest
//
//  Created by Sam Madden on 2/15/17.
//  Copyright © 2017 Sam Madden. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@property IBOutlet UILabel *idLabel;
@property IBOutlet UILabel *rangeLabel;
@property IBOutlet UILabel *rssiLabel;

@end

