This directory contains some sample acceleration data in the run,
walk, car, ski, and train directories, as well as scripts to process
this data (and other demos from 6.S062 lecture on activity
recognition.)

class.py - simple example of a classifier running on dummy data

plot1.py - plot accel of one of the data files plot2.py - plot accel,
spectrogram, and power spectrum density (psd) on one file

plot3.py - plot accel, spectrogram, and psd of all files, and build simple
classifier to try to predict transport mode from input files.

The classifier outputs the training data, the test labels, and it
performance as well as a confusion matrix.  It also outputs the
decision tree decision variables as a Graphviz .dot file for
visualization purposes.

plot4.py - for car/2.csv, plot the accel & frequency data after
re-orientation in direction of travel of the car, and with gravity
removed (this was done by an external program)

