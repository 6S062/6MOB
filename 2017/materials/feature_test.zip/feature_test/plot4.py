import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math


#compute spectrogram when data has been re-oriented to direction of travel of car
#accel_lat/lon_smoothed columns contain this data (note that gravity has been removed)

file = "car/2.csv"
df1 = pd.read_csv(file)
a_sm= df1[['accel_lon_smoothed','accel_lat_smoothed']]
a_lon = df1['accel_lon_smoothed']
a_lon = filter(lambda a: not math.isnan(a), a_lon)

a_lat = df1['accel_lat_smoothed']
a_lat = filter(lambda a: not math.isnan(a), a_lat)

print "alat / alon corr: " + repr(np.corrcoef(a_lat,a_lon)[1][0])

font = {'family' : 'Helvetica',
        'size'   : 8}
    
plt.rc('font', **font)


plt.subplot(231)
plt.plot(a_lat)
plt.ylabel('alat')
plt.subplot(232)
plt.specgram(a_lat, 512, 20)
plt.subplot(233)
(plat, flat) = plt.psd(a_lat, 512, 20)
plt.ylabel('')


plt.subplot(234)
plt.plot(a_lon)
plt.ylabel('alon')
plt.subplot(235)
plt.specgram(a_lon, 512, 20)
plt.subplot(236)
(plon,flon) = plt.psd(a_lon, 512, 20)
plt.ylabel('')

print "powerlat / powerlon corr: " + repr(np.corrcoef(plon,plat)[1][0])

fig = plt.gcf()
fig.set_size_inches(8,8)
fig.savefig("car2.png", dpi=300)
plt.close()
#plt.show(block=True)
