import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math

file = "bike/1.csv"

vars = ['ax','ay','az']
df1 = pd.read_csv(file)

#plot magnitude
a = df1[vars]
mag = np.linalg.norm(a, axis=1)
mag = filter(lambda a: not math.isnan(a), mag)

plt.plot(mag)
plt.show()
