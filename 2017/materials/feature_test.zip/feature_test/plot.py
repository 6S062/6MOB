import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from sklearn.tree import DecisionTreeClassifier
import numpy as np
from sklearn.metrics import confusion_matrix
import sklearn.tree as tree

global log
log = math.log
files = ["run/1.csv","walk/1.csv","bike/1.csv","bike/2.csv","car/1.csv","car/2.csv","train/1.csv","train/2.csv","ski/1.csv","ski/2.csv"]
classes = [0,0,1,1,2,2,3,3,4,4]
metrics = []

idx = 0
for file in files:
    met = []
    print file
    
    vars = ['ax','ay','az']
    df1 = pd.read_csv(file)
    a = df1[vars]
    mag = np.linalg.norm(a, axis=1)
    mag = filter(lambda a: not math.isnan(a), mag)
    acs = {}
    font = {'family' : 'Helvetica',
            'size'   : 8}

    plt.rc('font', **font)

    numplots = len(vars)+1

    curplot = 1
    yoff = 0
    # plot each of x,y,z separately
    for v in vars:
        s = ""
        av = df1[v] 
        av = filter(lambda a: not math.isnan(a), av)
        mu = np.mean(av)
        av = av - mu
        acs[v] = av
        s = s + v + " acc std: " + ("%.2f" % np.std(av)) + "\n"
        plt.subplot(numplots,3,curplot)
        plt.plot(av)
        plt.ylabel(v)
        plt.subplot(numplots,3,curplot+1)
        plt.specgram(av, 512, 20)
        plt.subplot(numplots,3,curplot+2)
        (power,freq) = plt.psd(av, 512, 20,detrend=plt.mlab.detrend_none)
        power = power[2:]
        freq = freq[2:]

        mean = np.mean(power)
        s = s + v +  " psd entropy: " + ("%.2f" % plt.mlab.entropy(power, 20)) + "\n"
        s = s + v +  " psd std: " + ("%.2f" % np.std(power))
        plt.ylabel('')
        curplot = curplot + 3
        axes = plt.gca()
        yl = axes.get_ylim()
        plt.text(2, yl[1] + (yl[0]-yl[1]) * .3, s, fontsize=8)
        
        yoff = yoff + 10

    print "ax / ay corr: " + repr(np.corrcoef(acs['ax'],acs['ay'])[1][0])
    print "ax / az corr: " + repr(np.corrcoef(acs['ax'],acs['az'])[1][0])
    print "ay / az corr: " + repr(np.corrcoef(acs['ay'],acs['az'])[1][0])

    #plot magnitude
    plt.subplot(numplots,3,curplot)
    plt.plot(mag)
    plt.ylabel('mag')
    plt.subplot(numplots,3,curplot+1)
    plt.specgram(mag, 512, 20)
    plt.ylabel('')
    plt.subplot(numplots,3,curplot+2)
    plt.psd(mag, 512, 20)
    (power,freq) = plt.psd(mag, 512, 20,detrend=plt.mlab.detrend_none)
    power = power[2:]
    freq = freq[2:]
    mean = np.mean(mag)
    meanpower = np.mean(power)
    s = "mag mu = " + ("%.2f" % mean) + "\n"
    s = s + "psd e: " + ("%.2f" % plt.mlab.entropy(power, 20)) + "; mu = " + ("%.2f" % meanpower) + "\n"
    s = s + "psd std: " + ("%.2f" % np.std(power))
    axes = plt.gca()
    yl = axes.get_ylim()
    plt.text(2, yl[1] + (yl[0]-yl[1]) * .25, s, fontsize=8)

    # record a bunch of metrics of magnitude
    met.append(mean)
    met.append(plt.mlab.entropy(power, 20))
    met.append(meanpower)
    met.append(np.std(power))
    met.append(np.max(power))
    met.append(freq[np.argmax(power)])
    plt.ylabel('')
    
    plt.suptitle(file)

    fig = plt.gcf()
    fig.set_size_inches(8,8)
    fig.savefig(repr(idx) + ".png", dpi=300)
    idx = idx + 1
    plt.close()
    #plt.show(block=True)
    metrics.append(met)


print ['mag_mean','mag_power_entropy','mag_power_mean', 'mag_power_std', 'mag_power_max', 'mag_power_max_freq']
for m in metrics:
    for v in m:
        print ("%.2f, " % v),
    print
print classes


clf = DecisionTreeClassifier(random_state=0)

clf.fit(metrics,classes)
print clf
print clf.predict(metrics)
print classes
cm = confusion_matrix(classes,clf.predict(metrics))
print cm

with open('graph.dot', 'w') as file:
    tree.export_graphviz(clf, out_file = file)




file = "car/2.csv"
df1 = pd.read_csv(file)
a_sm= df1[['accel_lon_smoothed','accel_lat_smoothed']]
a_lon = df1['accel_lon_smoothed']
a_lon = filter(lambda a: not math.isnan(a), a_lon)

a_lat = df1['accel_lat_smoothed']
a_lat = filter(lambda a: not math.isnan(a), a_lat)

print "alat / alon corr: " + repr(np.corrcoef(a_lat,a_lon)[1][0])


plt.subplot(231)
#a.plot()
plt.plot(a_lat)
plt.ylabel('alat')
plt.subplot(232)
plt.specgram(a_lat, 512, 20)
plt.subplot(233)
(plat, flat) = plt.psd(a_lat, 512, 20)
plt.ylabel('')



plt.subplot(234)
#a.plot()
plt.plot(a_lon)
plt.ylabel('alon')
plt.subplot(235)
plt.specgram(a_lon, 512, 20)
plt.subplot(236)
(plon,flon) = plt.psd(a_lon, 512, 20)
plt.ylabel('')

print "powerlat / powerlon corr: " + repr(np.corrcoef(plon,plat)[1][0])

fig = plt.gcf()
fig.set_size_inches(8,8)
fig.savefig("car2.png", dpi=300)
idx = idx + 1
plt.close()
#plt.show(block=True)
