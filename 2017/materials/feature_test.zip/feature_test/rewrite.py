import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from sklearn.tree import DecisionTreeClassifier
import numpy as np
from sklearn.metrics import confusion_matrix
import sklearn.tree as tree

files = ["run/1.csv","walk/1.csv","bike/1.csv","bike/2.csv","car/1.csv","car/2.csv","train/1.csv","train/2.csv","ski/1.csv","ski/2.csv"]

for file in files:
    met = []
    print file
    
    vars = ['ax','ay','az','accel_lon_smoothed','accel_lat_smoothed']
    df1 = pd.read_csv(file)
    a = df1[vars]
    a.to_csv(file, index=False, na_rep='nan')
