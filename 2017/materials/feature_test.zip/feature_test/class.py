#from sklearn.cross_validation import cross_val_predict
from sklearn.tree import DecisionTreeClassifier
import numpy as np
from sklearn.metrics import confusion_matrix
import sklearn.tree as tree

clf = DecisionTreeClassifier(random_state=0, criterion='entropy')

# mean, energy
data = np.array([[.4,.5],
                 [.1,.2],
                 [.2,.6],
                 [.5,.1],
                 [.05,.9],
                 [.6,.1]])



labels= np.array([1,0,0,1,0,1])

clf.fit(data,labels)
print clf
print clf.predict(data)
print labels
cm = confusion_matrix(labels,clf.predict(data))
print cm

with open('graph.dot', 'w') as file:
    tree.export_graphviz(clf, out_file = file)

#print cross_val_predict(clf, data, labels, cv=2)
