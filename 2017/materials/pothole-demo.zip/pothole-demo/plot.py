import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix
import sklearn.tree as tree
from scipy.signal import butter, lfilter, freqz

def butter_highpass(cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='high', analog=False)
    return b, a

def butter_highpass_filter(data, cutoff, fs, order=5):
    b, a = butter_highpass(cutoff, fs, order=order)
    y = lfilter(b, a, data)
    return y

# Filter requirements.
order = 6
fs = 380.0       # sample rate, Hz
cutoff = 50  # desired cutoff frequency of the filter, Hz


files = ["data_3408","data_3409"]

idx = 0
for file in files:
    vars = ['time','lat','lon','sensor','speed', 'ax','ay','az']
    df1 = pd.read_csv(file,names=vars, sep=' ')
#    print df1

    ax = df1['ax'] - np.mean(df1['ax'])
    ay = df1['ay'] - np.mean(df1['ay'])
    az = df1['az'] - np.mean(df1['az'])

    
    # Filter the data, and plot both the original and filtered signals.
    fz = butter_highpass_filter(az, cutoff, fs, order)

    plt.subplot(4, 1, 2)
    plt.plot(fz, 'g', linewidth=1, label='filtered data')
    plt.plot(az-np.mean(az), color='.6', label='zdata')
    plt.grid()
    plt.legend()

    #compute zpeak 
    max_idx = np.argmax(fz)
    maxz = np.max(fz)

    #find filtered x daa around peak
    fx = butter_highpass_filter(ax, cutoff, fs, order)
    for i in range(0,len(fx)):
        if abs(max_idx - i) > 40:
            fx[i] = 0

    #plot filtered x data around peak
    plt.subplot(4, 1, 3)
    plt.plot(fx, 'r-', linewidth=1, label='filtered data near z-peak')
    plt.plot(ax-np.mean(ax), color='.6', label='xdata')
    plt.grid()
    plt.legend()

    #plot fx / maxz ratio
    ratio = fx/maxz
    #print ratio
    plt.subplot(4, 1, 1)
    plt.plot(ratio, label = "Filt X / Zmax")
    plt.grid()
    plt.xlabel('Time [sec]')
    plt.legend()

    #plot maxz / speed ratio
    speed =  df1['speed'] 
    ratio = maxz/speed
    plt.subplot(4, 1,4)
    plt.plot(ratio, label = "Zmax / speed")
    plt.grid()
    plt.xlabel('Time [sec]')
    plt.legend()

    
    plt.subplots_adjust(hspace=0.35)
    plt.show()
