

for f in data_*; do
    gnuplot <<EOF
    set terminal png size 320,240 font "/usr/share/fonts/bitstream-vera/Vera.ttf" 10
    set output "$f.png"
    plot "$f" using 8 title "Z" with lines, \
           "$f" using 7 title "Y" w l, \
               "$f" using 6 title "X" w l
EOF
done

