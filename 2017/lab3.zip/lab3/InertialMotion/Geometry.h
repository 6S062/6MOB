//
//  Geometry.h
//  InertialMotion
//
//  Created by Peter Iannucci on 3/28/16.
//  Copyright © 2016 MIT. All rights reserved.
//

#import <GLKit/GLKit.h>

GLKMatrix3 NearestRotation(GLKMatrix3 input);
