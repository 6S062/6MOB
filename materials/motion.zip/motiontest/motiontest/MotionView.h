//
//  MotionView.h
//  motiontest
//
//  Created by Sam Madden on 3/8/16.
//  Copyright © 2016 Sam Madden. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MotionView : UIView

@end
