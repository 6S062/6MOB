//
//  ViewController.m
//  motiontest
//
//  Created by Sam Madden on 3/8/16.
//  Copyright © 2016 Sam Madden. All rights reserved.
//

#import "ViewController.h"
#import "MotionView.h"

@interface ViewController () {
}
@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    MotionView *v = [[MotionView alloc] init];
    v.frame = self.view.frame;
    [self.view addSubview:v];
    self.view.userInteractionEnabled = TRUE;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
