//
//  MotionView.m
//  motiontest
//
//  Created by Sam Madden on 3/8/16.
//  Copyright © 2016 Sam Madden. All rights reserved.
//

#import "MotionView.h"
#import <CoreMotion/CoreMotion.h>

#define abs(x) ((x)<0?((x)*-1):(x))


@implementation MotionView {
    CMMotionManager *_cm;
    NSOperationQueue *_q;
    NSLock *_l;
    NSMutableArray<NSValue *> *_points;
    CGPoint _lastLoc, _curLoc;
    CGPoint _vel;
    double _lastYaw;
}


-(id)init {
    self = [super init];
    self.userInteractionEnabled = TRUE;
    _points = [[NSMutableArray alloc] init];
    _cm = [[CMMotionManager alloc] init];
    _q = [[NSOperationQueue alloc] init];
    _l = [[NSLock alloc] init];
    _lastLoc = _curLoc = CGPointMake(0, 0);
    _vel = CGPointMake(0, 0);
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped:)];
    tap.numberOfTapsRequired = 2;
    [self addGestureRecognizer:tap];
    
    UITapGestureRecognizer *onetap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onetap:)];
    [self addGestureRecognizer:onetap];

    _cm.deviceMotionUpdateInterval = .005;
    
    [_cm startDeviceMotionUpdatesUsingReferenceFrame:CMAttitudeReferenceFrameXArbitraryCorrectedZVertical /*CMAttitudeReferenceFrameXMagneticNorthZVertical*/ toQueue:_q withHandler:^(CMDeviceMotion * _Nullable motion, NSError * _Nullable error) {
        [self updatePositionWithAccel:motion.userAcceleration andAttitude:motion.attitude];
        [_l unlock];
    }];

    return self;
}

//double tap handler -- reset current velocity & points
- (void)tapped:(UITapGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        [self reset];
    }
}

//single tap handler -- set velocity to 0
- (void)onetap:(UITapGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        [_l lock];
        _vel = CGPointMake(0, 0);
        [_l unlock];

    }
}



//reset the current velocity & points
-(void) reset {
    [_l lock];
    _lastLoc = _curLoc = CGPointMake(0, 0);
    _vel = CGPointMake(0, 0);
    _points = [[NSMutableArray alloc] init];
    [_l unlock];
    [self setNeedsDisplay];


}

#define kTHRESH 0.0001

//should be called with lock held
-(void) updatePositionWithAccel:(CMAcceleration)accel andAttitude:(CMAttitude *)att {
    BOOL reorient = TRUE;
    
    [_l lock];

    //update x velocity
    //thresh test suppresses almost motionless points
    if (abs(accel.x) > kTHRESH) {
        if (reorient) //reorient means we apply the gyro rotation so the
                      // accel signal is relative to the initial frame set up
                      // when we start sampling
            _vel.x += accel.x * cos(att.yaw) - accel.y*sin(att.yaw);
        else
            _vel.x += accel.x;
    } else {
        _vel.x = 0;
    }
    
    //update y velocity
    if (abs(accel.y) > kTHRESH) {
        if (reorient)
            _vel.y += accel.x * sin(att.yaw) + accel.y *cos(att.yaw);
        else
             _vel.y += accel.y*-1;
    } else {
        _vel.y = 0;
    }

    //compute the new location
    CGPoint p = CGPointMake(_curLoc.x + _vel.x, _curLoc.y + _vel.y);
    _curLoc = p;

    
    //only draw readings where the line has moved by at least 1 px
    if (abs(_lastLoc.x - p.x) > 1.0 ||  abs(_lastLoc.y - p.y) > 1.0 || abs(_lastYaw - att.yaw) > .01) {
        _lastLoc = p;
        _lastYaw = att.yaw;

        [_points addObject:[NSValue valueWithCGPoint:p]];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self setNeedsDisplay];
        });
    }
    [_l unlock];
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    BOOL rotate = TRUE;
    [super drawRect:rect];
    CGPoint center = CGPointMake(CGRectGetMidX(self.frame),CGRectGetMidY(self.frame));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClearRect(context,self.bounds);
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    
    CGContextSetLineWidth(context, 2.0f);
    
    [_l lock];
    if (rotate) {
        double newX = center.x;
        double newY = center.y;
        CGContextTranslateCTM(context,newX,newY);

        CGContextRotateCTM(context, _lastYaw);
        CGContextTranslateCTM(context,-newX,-newY);
    }
    CGContextMoveToPoint(context, center.x, center.y);
    for (NSValue *v in _points) {
        CGPoint next = [v CGPointValue];
        CGFloat x = next.x + center.x, y = next.y + center.y;
        CGContextAddLineToPoint(context, x, y );

    }
    [_l unlock];
    // and now draw the Path!
    CGContextStrokePath(context);

    
}


@end
