import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math

file = "bike/1.csv"

    
vars = ['ax','ay','az']
df1 = pd.read_csv(file)

acs = {}
font = {'family' : 'Helvetica',
        'size'   : 12}

plt.rc('font', **font)

plt.suptitle(file)

numplots = 1
curplot = 1
#plot magnitude
a = df1[vars]
mag = np.linalg.norm(a, axis=1)
mag = filter(lambda a: not math.isnan(a), mag)
mean = np.mean(mag)
mag = mag - mean

plt.subplot(3,numplots,curplot)
plt.plot(mag)
plt.ylabel('mag')
plt.subplot(3,numplots,curplot+1)
plt.specgram(mag, 512, 20)
plt.ylabel('')
plt.subplot(3,numplots,curplot+2)
(power,freq) = plt.psd(mag, 512, 20,detrend=plt.mlab.detrend_none)
meanpower = np.mean(power)
s = "mag mu = " + ("%.2f" % mean) + "\n"
s = s + "psd e: " + ("%.2f" % plt.mlab.entropy(power, 20)) + "; mu = " + ("%.2f" % meanpower) + "\n"
s = s + "psd std: " + ("%.2f" % np.std(power))
axes = plt.gca()
yl = axes.get_ylim()
plt.text(2, yl[1] + (yl[0]-yl[1]) * .25, s, fontsize=8)

plt.ylabel('')
plt.show()

