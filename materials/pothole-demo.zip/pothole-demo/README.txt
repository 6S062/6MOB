This directory contains the acceleration data from the top 10 largest
potholes detected during the pothole patrol experiments, as well as
scripts to filter this data using the filters from the paper.


plot.py plots two of the drives, showing four plots corresponding to the four stages of filtering:
        Plot 1 --  filtered x / zmax
        Plot 2 --  filtered z data
        Plot 3 --  filtered x data -- used as input to plot 1
        Plot 4 -- ZMax / speed

filter.py shows an example of filtering and the frequency response of the filters

Python scripts depend on numpy and scipy.

